package com.example.simplecalculator

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.simplecalculatorwithmultiplescreens.R

class HistoryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        val tvHistory = findViewById<TextView>(R.id.tvHistory)

        // Retrieve calculation results passed from MainActivity using Intent extras
        val historyList = intent.getStringArrayListExtra("HISTORY_LIST")

        if (!historyList.isNullOrEmpty()) {
            tvHistory.text = historyList.joinToString(separator = "\n")
        } else {
            tvHistory.text = "No calculations performed yet."
        }
    }
}