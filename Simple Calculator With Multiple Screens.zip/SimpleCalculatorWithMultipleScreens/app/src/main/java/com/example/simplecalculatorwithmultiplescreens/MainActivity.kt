package com.example.simplecalculator

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.simplecalculatorwithmultiplescreens.R

class MainActivity : AppCompatActivity() {

    // Store history strings in a list
    private val calculationHistory = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etNumber1 = findViewById<EditText>(R.id.etNumber1)
        val etNumber2 = findViewById<EditText>(R.id.etNumber2)
        val tvResult = findViewById<TextView>(R.id.tvResult)

        val btnAdd = findViewById<Button>(R.id.btnAdd)
        val btnSubtract = findViewById<Button>(R.id.btnSubtract)
        val btnMultiply = findViewById<Button>(R.id.btnMultiply)
        val btnDivide = findViewById<Button>(R.id.btnDivide)
        val btnViewHistory = findViewById<Button>(R.id.btnViewHistory)

        fun performCalculation(operation: String) {
            val num1Str = etNumber1.text.toString()
            val num2Str = etNumber2.text.toString()

            if (num1Str.isEmpty() || num2Str.isEmpty()) {
                Toast.makeText(this, "Please enter both numbers", Toast.LENGTH_SHORT).show()
                return
            }

            val num1 = num1Str.toDouble()
            val num2 = num2Str.toDouble()
            var result = 0.0

            when (operation) {
                "+" -> result = num1 + num2
                "-" -> result = num1 - num2
                "*" -> result = num1 * num2
                "/" -> {
                    if (num2 == 0.0) {
                        Toast.makeText(this, "Cannot divide by zero", Toast.LENGTH_SHORT).show()
                        return
                    }
                    result = num1 / num2
                }
            }

            val resultEntry = "$num1 $operation $num2 = $result"
            tvResult.text = "Result: $result"
            calculationHistory.add(resultEntry)
        }

        btnAdd.setOnClickListener { performCalculation("+") }
        btnSubtract.setOnClickListener { performCalculation("-") }
        btnMultiply.setOnClickListener { performCalculation("*") }
        btnDivide.setOnClickListener { performCalculation("/") }

        // Pass results using Intent extras and open HistoryActivity
        btnViewHistory.setOnClickListener {
            val intent = Intent(this, HistoryActivity::class.java)
            intent.putStringArrayListExtra("HISTORY_LIST", calculationHistory)
            startActivity(intent)
        }
    }
}